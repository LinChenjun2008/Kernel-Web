/*
puslearOS 1(pure 5_1_1)test5
*/
#ifndef PUSLEAR_OS
#define PUSLEAR_OS

#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cstring>
#include<string>
#include<ctime>

const int COL = 20;
const int COL_USER=10;
const int languages = 4;
const int CHINESE = 1;
const int F_CHINESE = 2;
const int ENGLISH = 3;
const int JAPANESE = 4;

const int START=1;
const int SHUTDOWN=2;
const int SIGNOUT=3;
const int REBOOT=4;

//�˵� 
struct Menu
{
    int menus;
    std::string Ch[COL];
    std::string Fc[COL];
    std::string En[COL];
    std::string Jp[COL];
    int num[COL];
};

std::string m_str="----------";

void Print(int,const Menu*,int);
void GUI(int,const Menu*,int show=1);

//template<typename T>
void Input(int & a);//���� 
int Enter(int & input,const Menu* m);//ѡ��
 
bool Booting();//���� 
void Bootmenu();//�������� 
void Errbooting();//����ʧ�� 
void ERROR(int mode);

void Shutdown();//�ػ� 
void Reboot();//���� 
void SignIn();//���� 

int test();

//�û� 
void User();
void User_information();
void Change_password();
void Add_user();//�����û�
void Change_user();//�л��û� 
void Del_user();//ɾ���û�
void Program();//���� 
void Attachment();//����
void Apps();//���� 
void Calculator();//������ 
void Games();//��Ϸ 
namespace GAMES
{

void guess();
}
void Set();//���� 
void Language_Set();//�������� 
void Sys_information();//ϵͳ��Ϣ	

void Stop(float a);

void SystemMenu();



//=======================================================================================

//�û�
class USER
{
	private:
		std::string name;//�û���
		std::string password;//���� 
		int language;//���� 
		unsigned int year;//�� 
		unsigned int month;//�� 
		unsigned int day;//�� 
		bool is_sign_in;//����״̬ 
	public:
		
		static unsigned int users;//�û����� 
		static int this_user;
		static int all_users;
		void Set_date(unsigned int y,unsigned int m,unsigned int d);//�������� 
		
		USER(){name="\0";password="\0";users++;}
		USER(std::string n,std::string pw,int lga,int y=2000,int m=1,int d=1);
		USER(const USER &);//���ƹ��캯�� 
		~USER(){users--;}
		
		std::string Name()const{return name;}//��ʾ�û��� 
		void Change_name(const std::string & n){name=n;}//�����û��� 
		
		std::string Password()const{return password;}
		bool Is_password(const std::string & pw)const{return (pw==password);}//ȷ������ 
		void Change_password(const std::string & pw){password=pw;}//�������� 
		
		void Change_language(int lga){language=lga;}//�����û����� 
		int Language()const{return language;}//����û����� 
		
		//void Set_date(unsigned int y,unsigned int m,unsigned int d);
		
		unsigned int Year()const{return year;}//�û� �� 
		unsigned int Month()const{return month;}//�û� �� 
		unsigned int Day()const{return day;}//�û� �� 
		
		void sign_in(){is_sign_in=true;}//���� 
		void sign_out(){is_sign_in=false;}//�ǳ� 
		bool Is_sign_in()const{return is_sign_in;} 
};

unsigned int USER::users=0;
int USER::this_user=0;
int USER::all_users=0;
USER::USER(std::string n,std::string pw,int lga,int y,int m,int d)
{
	users++;
	name=n;
	password=pw;
	language=lga;
	Set_date(y,m,d);
}

USER::USER(const USER & u)
{
	users++;
	name=u.name;
	password=u.password;
	year=u.year;
	month=u.month;
	day=u.day;
	language=u.language;
}

void USER::Set_date(unsigned int y,unsigned int m,unsigned int d)
{
	year=y;
	month=1;
	if(m>=1 && m<=12)
	{
		month=m;
		if(m%2==0)//2,4,6,8,10,12
		{
			if(m<=7 && m!=2 && d<=30)//4,6
			{
				day=d;
			}
			else if(m>=8 && d<=31)//8,10,12
			{
				day=d;
			}
			else if(m==2)
			{
				if(y%4==0 && d<=29)
				{
					day=d;
				}
				else if(y%4 != 0 && d<=28)
				{
					day=d;
				}
				else
				{
					day=1;
				}
			}
		}
		else if(m%2 !=0)//1,3,5,7,9,11
		{
			if(m<=8 && d<=31)//1,3,5,7
			{
				day=d;
			}
			else if(m>=8 && d<=30)//9,11
			{
				day=d;
			}
			else
			{
				day=1;
			}
		}
	}
}



//��Ϣ
class Information
{
	private:
		static int numbers;
		int informations;
		std::string information[50];
	public:
		Information():informations(0){}
		void write(const std::string &);
		void delet();
		void show();
};

int Information::numbers=0;

void Information::write(const std::string & in)
{
	information[informations]=in;
	informations++;
	numbers++;
}

void Information::delet()
{
	int i;
	for(i=0;i<informations;i++)
		information[i]="\0";
	numbers-=informations;
	informations=0;
}

void Information::show()
{
	int i;
	int j=0;
	for(i=0;i<informations;i++)
	{
		std::cout << m_str << std::endl;
		if(information[i] != "\0")
		{
			j++;
			std::cout << j <<')'<<information[i]<<std::endl;
			std::cout << m_str <<std::endl;
		}
	}
}
//========================================================================================

int language;
int systemmode=START;

std::string SystemVersion="PuslearOS test 5";//ϵͳ�汾 
int serial_number;//���к� 

/*std::string password="";
std::string inpassword;
std::string no_paeeword="";
*/

USER system_user[COL_USER]={
	USER("Adminiatior","\0",CHINESE,2021,7,1),
};//ϵͳ�û� 

int user_ptr_arr[COL_USER]={0};

Menu start=
{
    1,
    {"���ڿ���"},
    {"�����_�C"},
    {"Starting up"},
    {"����"},
    {0}
};

Menu shutdown=
{
	1,
	{"���ڹػ�"},
	{"�����P�C"},
	{"Shutdown in progress"},
	{"����åȥ������M����"},
	{0} 
};

Menu reboot=
{
	1,
	{"��������"},
	{"�����؆�"},
	{"Restarting"},
	{"������"},
	{0} 
};

Menu signIn=
{
	2,
	{"����","�ػ�"},
	{"����","�P�C"},
	{"Sign in","Shutdown"},
	{"��������","����åȥ�����"},
	{1,2}
};

Menu sign_menu=
{
	0,
	{"ѡ��һ���û�"},
	{"�x��һ���Ñ�"},
	{"Select a user"},
	{"��`���`���x�k"},
	{0}, 
};

Menu is_sign_in=
{
	0,
	{"(�ѵ���)"},
	{"(�ѵ���)"},
	{"(Logged in)"},
	{"(��������)"},
	{0}, 
};

Menu input_password=
{
	1,
	{"����������"},
	{"Ոݔ���ܴa"},
	{"Please enter password"},
	{"�ѥ���`�ɤ��������Ƥ�������"},
	{0} 
};

Menu err_password=
{
	1,
	{"������� \n"},
	{"�ܴa�e�` \n"},
	{"wrong password \n"},
	{"�g�`�ä��ѥ���`�� \n"},
};
//ϵͳ
Menu main_menu=
{
	0,
	{"�˵�"},
	{"�ˆ�"},
	{"Menu"},
	{"��˥�`"},
	{0},
};

Menu sys=
{
    5,
    {"�˵�","�û�","����","����","����"},
    {"�ˆ�","�Ñ�","����","����","�O��"},
    {"Menu","User","Public","Program","Settings"},
    {"��˥�`","��`���`","�ѥ֥�å�","�ץ������","�O��"},
    {1,2,3,4,5}
};
//ϵͳ->�˵�
Menu sys_m=
{
    4,
    {"����","�ػ�","ע��","����"},
    {"����","�P�C","�]�N","�؆�"},
    {"Return","Shutdown","Sign out","Restart"},
    {"����","����åȥ�����","����������","������"},
    {1,2,3,4}
};
//ϵͳ->�û�
Menu sys_user=
{
    3,
    {"����","��������","ע��"},
    {"����","�����ܴa","�]�N"},
    {"Return","Change Password","Sign out"},
    {"����","�ѥ���`�ɤ�������","���������Ȥ���"},
    {1,2,3},
};

//�û�
Menu user_menu=
{
	6,
	{"����","�û���Ϣ","��������","�����û�","�л��û�","ɾ���û�"},
	{"����","�Ñ���Ϣ","�����ܴa","�����Ñ�","�ГQ�Ñ�","�h���Ñ�"},
	{"Return","User Information","Change Password","Add User","Change user","delete users"},
	{"����","��`���`���","�ѥ���`�ɤΉ��","��`���`��׷��","��`���`���Ф��椨","��`���`����������"},
	{1,2,3,4,5,6}, 
};

Menu user_information=
{
	0,
	{"�û���:","����״̬:"},
	{"�Ñ���:","�����B:"},
	{"Username:","sign in status:"},
	{"��`���`����","�������󥹥Ʃ`������"},
	{0},
};

Menu enter_old_password=
{
	0,
	{"���������:"},
	{"ݔ���f�ܴa:"},
	{"Enter old password:"},
	{"�Ť��ѥ���`�ɤ��������Ƥ�������:"},
	{0},
};

Menu new_password=
{
	0,
	{"����������:","�ٴ�����������:"},
	{"ݔ�����ܴa:","�ٴ�ݔ�����ܴa:"},
	{"Enter new password:","Enter new password again:"},
	{"�¤����ѥ���`�ɤ��������Ƥ�������:","�¤����ѥ���`�ɤ�⤦һ���������Ƥ�������:"},
	{0},
};

Menu porgram_menu=
{
	3,
	{"����","����","����"},
	{"����","����","����"},
	{"Return","Attachment","Other"},
	{"��Ʒ","�����ե�����","������"},
	{1,2,3}, 
};

Menu attachment_menu=
{
	3,
	{"����","Ӧ�ó���","��Ϸ"},
	{"����","���ó���","�[��"},
	{"Return","Application","Game"},
	{"��Ʒ","���ץꥱ�`�����","���`��"},
	{1,2,3}, 
};

Menu applicatior_menu=
{
	4,
	{"����","������","��Ϣ","ͨѶ¼"},
	{"����","Ӌ����","��Ϣ","ͨӍ�"},
	{"Return","Calculator","Information","Contacts"},
	{"��Ʒ","�׿","���","�B�j��"},
	{1,2,3,4},
};

Menu game_menu=
{
	2,
	{"����","��ʼ��Ϸ"},
	{"����","�_ʼ�[��"},
	{"Return","Start the game"},
	{"����","���`����_ʼ����"},
	{1,2}, 
};

Menu set_menu={//���ò˵�
	5,
	{"����","��������","ʱ������","ϵͳ����","ϵͳ��Ϣ"},
	{"����","�Z���O��","�r�g�O��","ϵ�y�O��","ϵ�y��Ϣ"},
	{"Return","Language Setting","Time Setting","System Setting","System Information"},
	{"����","���Z�O��","�r�g�O��","�����ƥ��O��","�����ƥ����"},
	{1,2,3,4,5},
};
 
Menu languageSet=
{//�������� 
	languages,
	{"����","����(����)","English","�ձ��Z"},
	{"����","����(����)","English","�ձ��Z"},
	{"����","����(����)","English","�ձ��Z"},
	{"����","����(����)","English","�ձ��Z"},
	{CHINESE,F_CHINESE,ENGLISH,JAPANESE}
};

Menu sys_information=
{
	0, 
	{"ϵͳ�汾:","��Ȩ����:","���к�:"},
	{"ϵ�y�汾:","�������:","����̖:"},
	{"System Version:","Copyright:","Serial Number:"},
	{"�����ƥ�Щ`�����:","������:","���ꥢ�뷬��:"},
	{0} 
};

Menu exitMenu=
{
	0,
	{"<����\"0\" �˳�>"},
	{"<ݔ��\"0\" �˳�>"},
	{"<Enter\"0\" Exit>"},
	{"<\"0\"���������ƽK�ˤ��ޤ�>"},
	{0}, 
};

int main()
{
	std::srand(std::time(0));
	using namespace std;
	bool true_boot = Booting();
	system_user[USER::this_user].Change_language(CHINESE);
	
	serial_number=rand()%10000;
	
    if(!true_boot)
    {
        Errbooting();
        return 0;
    }
    int in;
    while(1)
    {
    	std::cout << std::endl << std::endl << std::endl;
    	systemmode=START;
	    GUI(system_user[USER::this_user].Language(),&signIn);
	    Input(in);
	    Enter(in,&signIn);
	    switch(in)
	    {
	    	case 1://���� 
	    		SignIn();
	    		break;
	    	case 2://�ػ� 
	    		systemmode=SHUTDOWN; 
	    		break;
		}
		
		if(SHUTDOWN==systemmode)
		{
			Shutdown();
			return 0;
		}
		if(REBOOT==systemmode)
		{
			Reboot();
			systemmode=START;
			Booting();
			continue;
		}
	}
	return 0;
}

void SignIn()
{
	int in=0,limit=0;
	while(1)
	{
		if(systemmode != START)
		{
			return;
		}
		std::cout << std::endl << std::endl << std::endl;
		//ѡ���û�
		Print(system_user[USER::this_user].Language(),&sign_menu,0);
		std::cout << std::endl;
		for(int i=0;i<USER::users;i++)
		{
			if(system_user[i].Name() != "\0")
			{
				std::cout << m_str << std::endl;
				std::cout << limit+1 << ")" << system_user[i].Name();
				if(system_user[i].Is_sign_in())
				{
					Print(system_user[USER::this_user].Language(),&is_sign_in,0);
				}
				std::cout << std::endl;
				limit++;
				USER::all_users=limit;//��¼��ռλ�û��� 
			}
		}
		std::cout << m_str << std::endl;
		
		Input(in);
		if(in>limit || in <= 0)
		{
			continue;
		}
		USER::this_user=(in-1)+user_ptr_arr[in-1];
		break;
	}
	//�������� 
	while(1)
	{
		if(system_user[USER::this_user].Is_sign_in())
		{
			test();
			return;
		}
		if(!(system_user[USER::this_user].Is_password("\0")))
		{
			std::string inpassword;
			GUI(system_user[USER::this_user].Language(),&input_password,0);
			std::cin >> inpassword;
			if(system_user[USER::this_user].Is_password(inpassword))
			{
				test();
				return;
			}
			else
			{
				Print(system_user[USER::this_user].Language(),&err_password,0);
				continue;
			}
		}
		else
		{
			test();
			return;
		}
	}
}

int test()
{
	system_user[USER::this_user].sign_in();//�����û� 
    using namespace std;
    int in;
    while(START==systemmode)
    {
    	std::cout << std::endl << std::endl << std::endl;
    	//Print(system_user[USER::this_user].Language(),&main_menu,0);
	    GUI(system_user[USER::this_user].Language(),&sys);
	    int in;
	    Input(in);
	    Enter(in,&sys);
	    switch(in)
	    {
	    case 1:
	        SystemMenu();
	        break;
	    case 2:
	        User();
	        break;
	    case 3:
	    	
	    	break;
	    case 4:
	    	Program();
	    	break;
	    case 5:
	    	Set();
	    	break;
	    default:
	    	
	    	break;
	    }
	}
    return 0;
}

bool Booting()
{
	//�����û�
	if(systemmode == START)//���������,�򴴽�Ĭ���û� 
	{
	 //	system_user[USER::users]=USER("Adminiatior","",2021,7,1);
	}
	
	//��ȡ�ļ�
	
    /*std::fstream fio("puslear.dat",std::ios_base::in|std::ios_base::binary);
    if(!fio.is_open())
    {
        std::ofstream fout("puslear.dat",std::ios_base::binary|std::ios_base::out);

        return false;
    }
   // fio.read((std::string)&data,sizeof data);
    fio.close();*/
    	
	GUI(system_user[USER::this_user].Language(),&start,0);
	
    systemmode=START;
    Stop(1);
    //std::srand(int(time(NULL)));
    //std::cout << "Eytoue Company" << std::endl << "PuslearOS" <<std::endl;
    for(int i=0;i<5;i++)
        Bootmenu();
    return true;
}

void Bootmenu()
{
    /*int i,j;
    //srand(int(time(NULL)));
    std::cout<<" PuslearOS   "<<std::endl;
    std::cout<<"[          ]\b\b\b\b\b\b\b\b\b\b\b"<<std::flush;
    for(i=0; i<10; i++)
    {
        Stop(0.1);
        std::cout<<"#"<<std::flush;
    }
    std::cout << std::endl;*/
    std::string boot01="]         ";
    std::string boot02="[]        ";
    std::string boot03=" []       ";
    std::string boot04="  []      ";
    std::string boot05="   []     ";
    std::string boot06="    []    ";
    std::string boot07="     []   ";
    std::string boot08="      []  ";
    std::string boot09="       [] ";
    std::string boot10="        []";
    std::string boot11="         [";
    std::string boot12="          ";
    std::string*pm[12]={
    &boot01,&boot02,&boot03,&boot04,
    &boot05,&boot06,&boot07,&boot08,
    &boot09,&boot10,&boot11,&boot12
    };
    for(int i=0;i<12;i++)
    {
        std::cout << *pm[i] << std::flush;
        Stop(0.09);
        std::cout <<"\b\b\b\b\b\b\b\b\b\b"<<std::flush;
        Stop(0.01);
    }
}

void Errbooting()
{
    std::cout << m_str << std::endl;
    std::cout << "����" << std::endl;
    std::cout << "Error" << std::endl<<std::endl;
    std::cout <<"�����ԭ��"<<std::endl
         <<"�޷���\"puslear.dat\"�ļ� "<<std::endl<<std::endl;
    std::cout <<"The reason for the error:"<<std::endl
         <<" Cannot open the \"puslear.dat\" file "<<std::endl;
    std::cout << m_str << std::endl;
}

void ERROR(int mode)//2021.6.24
{
	std::cout << "====================" << std::endl;
	std::cout << std::endl;
	std::cout << "                    " << std::endl;
	std::cout << "Error :             " <<std::endl;
	std::cout << "There are some wrong with this system" << std::endl << std::endl;
	std::cout << "We need to reboot this system" << std::endl;
	std::cout << "====================" << std::endl;
	Stop(3);
	systemmode=mode;
}

void Shutdown()
{
    /*std::fstream fio("puslear.dat",std::ios_base::out|std::ios_base::binary);
    if(!fio.is_open())
    {
        std::ofstream fout("puslear.dat",std::ios_base::binary|std::ios_base::out);

        return;
    }
    fio.write((std::string)&data,sizeof data);
    fio.close();*/
    GUI(system_user[USER::this_user].Language(),&shutdown,0);
    for(int i=0;i<5;i++)
    {
    	Bootmenu();
	}
    return;
}

void Reboot()
{
	GUI(system_user[USER::this_user].Language(),&reboot,0);
	for(int i=0;i<3;i++)
	{
		Bootmenu();
	}
	return;
}

void Stop(float a)
{
    clock_t delay = a * CLOCKS_PER_SEC;
    clock_t start=clock();
    while(clock() - start < delay)
    {
        ;
    }
}

void Print(int lga,const Menu* m,int i)//2021.6.23
{
	if(lga==CHINESE)
    {
        std::cout << m->Ch[i];
    }
    else if(lga==F_CHINESE)
    {
        std::cout << m->Fc[i];
    }
    else if(lga==ENGLISH)
    {
        std::cout << m->En[i];
    }
    else if(lga==JAPANESE)
    {
        std::cout << m->Jp[i];
    }
}

void GUI(int lga,const Menu* m,int show)
{
    std::cout << m_str <<std::endl;
    int i;
    for(i=0; i<m->menus; i++)
    {
    	if(show==1)
    	{
        std::cout << m->num[i]<<')';
    	}
        if(lga==CHINESE)
        {
            std::cout << m->Ch[i] << std::endl;
        }
        else if(lga==F_CHINESE)
        {
            std::cout << m->Fc[i] << std::endl;
        }
        else if(lga==ENGLISH)
        {
            std::cout << m->En[i] << std::endl;
        }
        else if(lga==JAPANESE)
        {
            std::cout << m->Jp[i] << std::endl;
        }
        std::cout << m_str << std::endl;
    }
}

//template<typename T>
void Input(int & a)
{
    while(!(std::cin >> a))
    {
        std::cin.clear();
        while(std::cin.get() !='\n')
        {
            continue;
        }
    }
}
int Enter(int & input,const Menu* m)
{
    int i;
    for(i=0; i<(m->menus); i++)
    {
        if(input==m->num[i])
        {
            return m->num[i];
        }
    }
    input=0;
    return 0;
}
    
void SystemMenu()
{
	if(systemmode != START)
	{
		return;
	}
	
	int in;
	std::cout << std::endl << std::endl << std::endl;
	Print(system_user[USER::this_user].Language(),&main_menu,0);
	std::cout << std::endl;
	GUI(system_user[USER::this_user].Language(),&sys_m);
	Input(in);
	Enter(in,&sys_m);
	switch(in)
	{
		case 1:
			break;
		case 2:
			systemmode=SHUTDOWN;//ϵͳģʽ=�ػ� 
			break;
		case 3:
			system_user[USER::this_user].sign_out();//ע����ǰ�û� 
			systemmode=SIGNOUT;//ϵͳģʽ=ע�� 
			break;
		case 4:
			systemmode=REBOOT;//ϵͳģʽ=���� 
			break;
	}

}

void User()//�û� 2021.6.30
{
	int in;
	while(1)
	{
		if(systemmode != START)
		{
			return;
		}
	
		std::cout << std::endl << std::endl << std::endl;
		Print(system_user[USER::this_user].Language(),&sys,1);
		std::cout << std::endl;
		GUI(system_user[USER::this_user].Language(),&user_menu);
		Input(in);
		Enter(in,&user_menu);
		switch(in)
		{
			case 1:
				return;
				break;
			case 2:
				User_information();//�û���Ϣ 
				break;
			case 3:
				Change_password();//�������� 
				 break;
			case 4:
				Add_user();//�����û� 
				break;
			case 5: 
				Change_user();
				break;
			case 6:
				Del_user();//ɾ���û�
				break; 
		}
	}
} 

void User_information()
{
	if(systemmode != START)
	{
		return;
	}
	
	int in;
	std::cout << std::endl << std::endl << std::endl;
	Print(system_user[USER::this_user].Language(),&user_menu,1);
	std::cout << std::endl << m_str << std::endl;
	Print(system_user[USER::this_user].Language(),&user_information,0);
	std::cout << system_user[USER::this_user].Name();
	std::cout << std::endl << m_str << std::endl;
	Print(system_user[USER::this_user].Language(),&user_information,1);
	std::cout << system_user[USER::this_user].Is_sign_in();
	std::cout << std::endl << m_str << std::endl;
	Print(system_user[USER::this_user].Language(),&exitMenu,0);
	while(1)
	{
		Input(in);
		if(in==0)
		{
			break;
		}
	}
}

void Change_password()
{
	if(systemmode != START)
	{
		return;
	}
	
	int in;
	std::string old_p="\0";
	std::string new_p,new_p_2;
	std::cout << std::endl << std::endl << std::endl;
	if(!(system_user[USER::this_user].Is_password("\0")))//���벻��Ĭ�����루��tese 4�Ĳ�֮ͬ��:if(...);{...} -> if(...){...}
	{
		Print(system_user[USER::this_user].Language(),&enter_old_password,0);
		std::cin >> old_p;
		std::cout << std::endl;
	}
	if(system_user[USER::this_user].Is_password(old_p))
	{
		Print(system_user[USER::this_user].Language(),&new_password,0);//���������� 
		std::cin >> new_p;
		std::cout << std::endl;
		Print(system_user[USER::this_user].Language(),&new_password,1);//�ٴ����������� 
		std::cin >> new_p_2;
		std::cout << std::endl;
		if(new_p==new_p_2)
		{
			system_user[USER::this_user].Change_password(new_p);
		}
		else
		{
			Print(system_user[USER::this_user].Language(),&err_password,0);
		}
	}
	else
	{
		Print(system_user[USER::this_user].Language(),&err_password,0);
	}
}

void Add_user()
{
	if(systemmode != START)
	{
		return;
	}
	
	if(USER::all_users==COL_USER)//�Ѿ��� COL_USER ���û� 
	{
		return;
	}
	int i,j;
	for(i=0;i<COL_USER;i++)
	{
		if(system_user[i].Name()=="\0")//��λ
		{
			j=i;
			break;	
		} 
	}
	std::string n;
	std::cout << std::endl << std::endl << std::endl;
	Print(system_user[USER::this_user].Language(),&user_information,0);
	std::cin >> n;
	system_user[j].Change_name(n);//�����û��� 
	system_user[j].Change_language(system_user[USER::this_user].Language());//�������� 
	USER::all_users++;
}

void Change_user()
{
	int in=0,limit=0;
	while(1)
	{
		std::cout << std::endl << std::endl << std::endl;
		//ѡ���û�
		Print(system_user[USER::this_user].Language(),&sign_menu,0);
		std::cout << std::endl;
		for(int i=0;i<USER::users;i++)
		{
			if(system_user[i].Name() != "\0")
			{
				std::cout << m_str << std::endl;
				std::cout << limit+1 << ")" << system_user[i].Name();
				if(system_user[i].Is_sign_in())
				{
					Print(system_user[USER::this_user].Language(),&is_sign_in,0);
				}
				std::cout << std::endl;
				limit++;
				USER::all_users=limit;//��¼��ռλ�û��� 
			}
		}
		std::cout << m_str << std::endl;
		
		Input(in);
		if(in>limit || in <= 0)
		{
			continue;
		}
		USER::this_user=(in-1)+user_ptr_arr[in-1];//ƫ����,��ֹɾ���û���������� 
		break;
	}
	//�������� 
	while(1)
	{
		if(system_user[USER::this_user].Is_sign_in())
		{
			break;
		}
		if(!(system_user[USER::this_user].Is_password("\0")))
		{
			std::string inpassword;
			GUI(system_user[USER::this_user].Language(),&input_password,0);
			std::cin >> inpassword;
			if(system_user[USER::this_user].Is_password(inpassword))
			{
				break;
			}
			else
			{
				Print(system_user[USER::this_user].Language(),&err_password,0);
				continue;
			}
		}
		break;
	}
	system_user[USER::this_user].sign_in();
}

void Del_user()
{
	if(USER::all_users<=1)
	{
		return;
	} 
	system_user[USER::this_user].Change_name("\0");
	//��λ
	int i;
	for(i=USER::this_user;i<COL_USER-1;i++)
	{
		system_user[i]=system_user[i+1];
		system_user[COL_USER-1].Change_name("\0");
	}
	//USER::all_users--;
	
	//�����û�ָ����(ƫ����) 
//	for(int i=USER::this_user;i<COL_USER;i++)
//	{
//		user_ptr_arr[i]=delets;
//	} 
	systemmode=SIGNOUT;
}

void Program()//���� 
{
	int in;
	while(1)
	{
		std::cout << std::endl << std::endl << std::endl;
		Print(system_user[USER::this_user].Language(),&sys,3);
		std::cout << std::endl;
		GUI(system_user[USER::this_user].Language(),&porgram_menu);
		Input(in);
		Enter(in,&porgram_menu);
		switch(in)
		{
			case 1:
				return;
				break;
			case 2:
				Attachment();//����
				break;
			case 3:
				 break;
		}
	}
}

void Attachment()
{
	int in;
	while(1)
	{
		if(systemmode != START)
		{
			return;
		}
	
		std::cout << std::endl << std::endl << std::endl;
		Print(system_user[USER::this_user].Language(),&porgram_menu,1);
		std::cout << std::endl;
		GUI(system_user[USER::this_user].Language(),&attachment_menu);
		Input(in);
		Enter(in,&attachment_menu);
		switch(in)
		{
			case 1:
				return;
				break;
			case 2:
				Apps();//Ӧ�ó��� 
				break;
			case 3:
				Games();//��Ϸ 
				break;
		}
	}
}

void Apps()//2021.6.25
{
	int in;
	while(1)
	{
		if(systemmode != START)
		{
			return;
		}
	
		std::cout << std::endl << std::endl << std::endl;
		Print(system_user[USER::this_user].Language(),&attachment_menu,1);
		std::cout << std::endl;
		GUI(system_user[USER::this_user].Language(),&applicatior_menu);
		Input(in);
		Enter(in,&applicatior_menu);
		switch(in)
		{
			case 1:
				return;
				break;
			case 2:
				Calculator();//������ 
				break;
			case 3:
				//��Ϣ 
				break;
			case 4:
				//ͨѶ¼ 
				break;
		}
	}
}

void Calculator()
{
	int in,x,y;
	while(1)
	{
		if(systemmode != START)
		{
			return;
		}
		std::cout << std::endl << std::endl << std::endl;
		std::cout << "********************" << std::endl;
		Print(system_user[USER::this_user].Language(),&applicatior_menu,1);//			������ 
		std::cout << std::endl << m_str << std::endl;//(M_str) 
		std::cout << "1 ) Exit" << std::endl;//			1 ) x+y
		std::cout << m_str << std::endl;//     .....
		std::cout << "2 ) x+y" << std::endl;
		std::cout << m_str << std::endl;
		std::cout << "3 ) x-y" << std::endl;
		std::cout << m_str << std::endl;
		std::cout << "4 ) x*y" << std::endl;
		std::cout << m_str << std::endl;
		std::cout << "5 ) x/y" << std::endl;
		std::cout << m_str << std::endl;
		Input(in);
		switch(in)
		{
			case 1:
				std::cout << std::endl << "********************" <<std::endl;
				return;
				break;
			case 2:
				 
				break;
			case 3:
				
				break;
			case 4:
				 
				break;
			case 5:
				
				break;
			default:
				continue;
				break;
		}
		std::cout << std::endl << "x=";
		Input(x);
		std::cout << std::endl << "y=";
		Input(y);
		if(2==in)
		{
			std::cout << std::endl << "x+y=" << x+y << std::endl;
			Stop(3);
		}
		else if(3==in)
		{
			std::cout << std::endl << "x-y=" << x-y << std::endl;
			Stop(3);
		}
		else if(4==in)
		{
			std::cout << std::endl << "x*y=" << x*y << std::endl;
			Stop(3);	
		}
		else if(5==in)
		{
			if(y==0)
			{
				std::cout << std::endl << "!(y=0)" <<std::endl << "Error" <<std::endl;
				Stop(3);
				continue;
			}
			std::cout << std::endl << "x/y=" << x/y << "......" << x%y << std::endl;
			Stop(3);	
		}
	}
}

void Games()
{
	int in;
	while(1)
	{
		if(systemmode != START)
		{
			return;
		}
		std::cout << std::endl << std::endl << std::endl;
		Print(system_user[USER::this_user].Language(),&attachment_menu,2);
		std::cout << std::endl;
		GUI(system_user[USER::this_user].Language(),&game_menu);
		Input(in);
		Enter(in,&game_menu);
		switch(in)
		{
			case 1:
				return;
				break;
			case 2:
				GAMES::guess();
				break;
		}
	}
}


void Set()//����
{
	int in;
	while(1)
	{
			if(systemmode != START)
		{
			return;
		}
		std::cout << std::endl << std::endl << std::endl;
		Print(system_user[USER::this_user].Language(),&sys,4);
		std::cout << std::endl;
		GUI(system_user[USER::this_user].Language(),&set_menu);
		Input(in);
		Enter(in,&set_menu);
		switch(in)
		{
			case 1:
				return;
				break;
			case 2:
				Language_Set();//�������� 
				break;
			case 3:
				//ʱ������ 
				break;
			case 4:
				//ϵͳ���� 
				break;
			case 5:
				Sys_information();	//ϵͳ��Ϣ 
				break;
			default:
				ERROR(REBOOT);//�쳣���� 
				break; 
		}
	}
}

void Language_Set()
{
	if(systemmode != START)
	{
		return;
	}
	
	int in;
	GUI(system_user[USER::this_user].Language(),&languageSet);
	Input(in);
	Enter(in,&languageSet);
	switch(in)
	{
		case CHINESE:
		case F_CHINESE:
		case ENGLISH:
		case JAPANESE:
			system_user[USER::this_user].Change_language(in);
			break;
		default:
		
			break; 
	}
	return;
}

void Sys_information()//2021.6.24
{
	if(systemmode != START)
	{
		return;
	}
	
	int in;
	std::cout << std::endl << std::endl << std::endl;
	Print(system_user[USER::this_user].Language(),&set_menu,4);
	std::cout << std::endl;
	std::cout << m_str << std::endl;
	Print(system_user[USER::this_user].Language(),&sys_information,0);//ϵͳ�汾 
	std::cout << SystemVersion << std::endl << m_str << std::endl;
	Print(system_user[USER::this_user].Language(),&sys_information,1);//��Ȩ��Ϣ
	std::cout << "Eytoue Tems" << std::endl << m_str << std::endl;
	Print(system_user[USER::this_user].Language(),&sys_information,2);
	std::cout << serial_number  << std::endl << m_str << std::endl;
	Print(system_user[USER::this_user].Language(),&exitMenu,0);
	while(1)
	{
		Input(in);
		if(in==0)
		{
			break;
		}
	}
}

namespace GAMES//2021.6.23
{
	void guess()
	{
		std::cout << "********************" <<std::endl;
		int ply,com;
		int min=0;
		int max=100;
		std::srand(std::time(0));
		int pass=((std::rand()%99)+1);
		while(1)
		{
			while(1)
			{
				std::cout << std::endl;
				std::cout << min << " < " << "#" << " < " << max <<std::endl;
				std::cout <<">:";
				Input(ply);
				if(min < ply && ply < pass)
				{
					min=ply;
					break;
				}
				else if(pass < ply && ply < max)
				{
					max=ply;
					break;
				}
				else if(ply==pass)
				{
					std::cout << std::endl;
					std::cout<< min << " < " << pass << " < " << max <<std::endl;
					std::cout << "********************" <<std::endl;
					return;
				}
				else
				{
					continue;
				}
			}
			while(1)
			{
//				std::cout << min << " < " << "#" << " < " << max <<std::endl;
//				std::cout <<"PuslareOS>:";
				com=((std::rand()%99)+1);
				if(min < com && com < pass)
				{
					//min=com;������ٸ�ֵ ,��ֹ����BUG 
				}
				else if(pass < com && com < max)
				{
					//max=com;
				}
				else if(com==pass)
				{
					
				}
				else
				{
					continue;
				}
				std::cout << std::endl;
				std::cout << min << " < " << "#" << " < " << max <<std::endl;
				std::cout <<"PuslareOS>:";
				std::cout << com <<std::endl;
				if(min < com && com < pass)
				{
					min=com;
				}
				else if(pass < com && com < max)
				{
					max=com;
				}
				else if(com==pass)
				{
					std::cout << std::endl;
					std::cout<< min << " < " << pass << " < " << max <<std::endl;
					std::cout << "********************" <<std::endl;
					return;
				}
				break;
			}
		}
		std::cout << "********************" <<std::endl;
	}
}

#endif
