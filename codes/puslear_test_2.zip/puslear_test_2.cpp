/*
puslearOS 1(pure 5_1_1)test2
*/
#ifndef PUSLEAR_OS
#define PUSLEAR_OS

#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cstring>
#include<string>
#include<ctime>

const int COL = 20;
const int languages = 4;
const int CHINESE = 1;
const int F_CHINESE = 2;
const int ENGLISH = 3;
const int JAPANESE = 4;

const int START=1;
const int SHUTDOWN=2;
const int SIGNOUT=3;
const int REBOOT=4;

//�˵� 
struct Menu
{
    int menus;
    std::string Ch[COL];
    std::string Fc[COL];
    std::string En[COL];
    std::string Jp[COL];
    int num[COL];
};

std::string m_str="----------";

void Print(int,const Menu*,int);
void GUI(int,const Menu*,int show=1);

//template<typename T>
void Input(int & a);//���� 
int Enter(int & input,const Menu* m);//ѡ��
 
bool Booting();//���� 
void Bootmenu();//�������� 
void Errbooting();//����ʧ�� 
void ERROR(int mode);

void Shutdown();//�ػ� 
void Reboot();//���� 
void SignIn();//���� 

int test();

void Program();//���� 
void Attachment();//����
void Games();//��Ϸ 
namespace GAMES
{

void guess();
}
void Set();//���� 
void Language_Set();//�������� 
void Sys_information();//ϵͳ��Ϣ	

void Stop(float a);

void SystemMenu();

int language;
int systemmode;

std::string SystemVersion="PuslearOS test 2";//ϵͳ�汾 
int serial_number;//���к� 

std::string password="201116";
std::string inpassword;
std::string no_paeeword="";

//=======================================================================================

//�û�
class USER
{
	private:
		std::string name;
		std::string password;
		unsigned int year;
		unsigned int month;
		unsigned int day;
		bool is_sign_in;
		static unsigned int users;
	public:
		void Set_date(unsigned int y,unsigned int m,unsigned int d);
		
		USER(){name="User";password="\a";users++;}
		USER(std::string n,std::string pw,int y=2000,int m=1,int d=1);
		
		std::string Name()const{return name;}
		void Change_name(const std::string & n){name=n;}
		
		bool Is_password(const std::string & pw)const{return (pw==password);}
		void Change_password(const std::string & pw){password=pw;}
		
		//void Set_date(unsigned int y,unsigned int m,unsigned int d);
		
		unsigned int Year()const{return year;}
		unsigned int Month()const{return month;}
		unsigned int Day()const{return day;}
		
		void sign_in(){is_sign_in=true;}
		void sign_out(){is_sign_in=false;}
};

unsigned int USER::users=0;

USER::USER(std::string n,std::string pw,int y,int m,int d)
{
	users++;
	name=n;
	password=pw;
	Set_date(y,m,d);
}
void USER::Set_date(unsigned int y,unsigned int m,unsigned int d)
{
	year=y;
	month=1;
	if(m>=1 && m<=12)
	{
		month=m;
		if(m%2==0)//2,4,6,8,10,12
		{
			if(m<=7 && m!=2 && d<=30)//4,6
			{
				day=d;
			}
			else if(m>=8 && d<=31)//8,10,12
			{
				day=d;
			}
			else if(m==2)
			{
				if(y%4==0 && d<=29)
				{
					day=d;
				}
				else if(y%4 != 0 && d<=28)
				{
					day=d;
				}
				else
				{
					day=1;
				}
			}
		}
		else if(m%2 !=0)//1,3,5,7,9,11
		{
			if(m<=8 && d<=31)//1,3,5,7
			{
				day=d;
			}
			else if(m>=8 && d<=30)//9,11
			{
				day=d;
			}
			else
			{
				day=1;
			}
		}
	}
}



//��Ϣ
class Information
{
	private:
		static int numbers;
		int informations;
		std::string information[50];
	public:
		Information():informations(0){}
		void write(const std::string &);
		void delet();
		void show();
};

int Information::numbers=0;

void Information::write(const std::string & in)
{
	information[informations]=in;
	informations++;
	numbers++;
}

void Information::delet()
{
	int i;
	for(i=0;i<informations;i++)
		information[i]="\t";
	numbers-=informations;
	informations=0;
}

void Information::show()
{
	int i;
	int j=0;
	for(i=0;i<informations;i++)
	{
		std::cout << m_str << std::endl;
		if(information[i] != "\t")
		{
			j++;
			std::cout << j <<')'<<information[i]<<std::endl;
			std::cout << m_str <<std::endl;
		}
	}
}
//========================================================================================

Menu start=
{
    1,
    {"���ڿ���"},
    {"�����_�C"},
    {"Starting up"},
    {"����"},
    {0}
};

Menu shutdown=
{
	1,
	{"���ڹػ�"},
	{"�����P�C"},
	{"Shutdown in progress"},
	{"����åȥ������M����"},
	{0} 
};

Menu reboot=
{
	1,
	{"��������"},
	{"�����؆�"},
	{"Restarting"},
	{"������"},
	{0} 
};

Menu signIn=
{
	2,
	{"����","�ػ�"},
	{"����","�P�C"},
	{"Sign in","Shutdown"},
	{"��������","����åȥ�����"},
	{1,2}
};

Menu input_password=
{
	1,
	{"����������"},
	{"Ոݔ���ܴa"},
	{"Please enter password"},
	{"�ѥ���`�ɤ��������Ƥ�������"},
	{0} 
};

Menu err_password=
{
	1,
	{"�������"},
	{"�ܴa�e�`"},
	{"wrong password"},
	{"�g�`�ä��ѥ���`��"},
};
//ϵͳ
Menu main_menu=
{
	0,
	{"�˵�"},
	{"�ˆ�"},
	{"Menu"},
	{"��˥�`"},
	{0},
};

Menu sys=
{
    5,
    {"�˵�","�û�","����","����","����"},
    {"�ˆ�","�Ñ�","����","����","�O��"},
    {"Menu","User","Public","Program","Settings"},
    {"��˥�`","��`���`","�ѥ֥�å�","�ץ������","�O��"},
    {1,2,3,4,5}
};
//ϵͳ->�˵�
Menu sys_m=
{
    4,
    {"����","�ػ�","ע��","����"},
    {"����","�P�C","�]�N","�؆�"},
    {"Return","Shutdown","Sign out","Restart"},
    {"����","����åȥ�����","����������","������"},
    {1,2,3,4}
};
//ϵͳ->�û�
Menu sys_user=
{
    3,
    {"����","��������","ע��"},
    {"����","�����ܴa","�]�N"},
    {"Return","Change Password","Sign out"},
    {"����","�ѥ���`�ɤ�������","���������Ȥ���"},
    {1,2,3}
};

Menu porgram_menu=
{
	3,
	{"����","����","����"},
	{"����","����","����"},
	{"Return","Attachment","Other"},
	{"��Ʒ","�����ե�����","������"},
	{1,2,3}, 
};

Menu attachment_menu=
{
	3,
	{"����","Ӧ�ó���","��Ϸ"},
	{"����","���ó���","�[��"},
	{"Return","Application","Game"},
	{"��Ʒ","���ץꥱ�`�����","���`��"},
	{1,2,3}, 
};

Menu game_menu=
{
	2,
	{"����","��ʼ��Ϸ"},
	{"����","�_ʼ�[��"},
	{"Return","Start the game"},
	{"����","���`����_ʼ����"},
	{1,2}, 
};

Menu set_menu={//���ò˵�
	5,
	{"����","��������","ʱ������","ϵͳ����","ϵͳ��Ϣ"},
	{"����","�Z���O��","�r�g�O��","ϵ�y�O��","ϵ�y��Ϣ"},
	{"Return","Language Setting","Time Setting","System Setting","System Information"},
	{"����","���Z�O��","�r�g�O��","�����ƥ��O��","�����ƥ����"},
	{1,2,3,4,5},
};
 
Menu languageSet=
{//�������� 
	languages,
	{"����","����(����)","English","�ձ��Z"},
	{"����","����(����)","English","�ձ��Z"},
	{"����","����(����)","English","�ձ��Z"},
	{"����","����(����)","English","�ձ��Z"},
	{CHINESE,F_CHINESE,ENGLISH,JAPANESE}
};

Menu sys_information=
{
	0, 
	{"ϵͳ�汾:","��Ȩ����:","���к�:"},
	{"ϵ�y�汾:","�������:","����̖:"},
	{"System Version:","Copyright:","Serial Number:"},
	{"�����ƥ�Щ`�����:","������:","���ꥢ�뷬��:"},
	{0} 
};

Menu exitMenu=
{
	0,
	{"<����\"0\" �˳�>"},
	{"<ݔ��\"0\" �˳�>"},
	{"<Enter\"0\" Exit>"},
	{"<\"0\"���������ƽK�ˤ��ޤ�>"},
	{0}, 
};

int main()
{
	std::srand(std::time(0));
	using namespace std;
	language=CHINESE;
	
	serial_number=rand()%10000;
	
	GUI(language,&start,0);
    if(!Booting())
    {
        Errbooting();
        return 0;
    }
    int in;
    while(1)
    {
    	std::cout << std::endl << std::endl << std::endl;
    	systemmode=START;
	    GUI(language,&signIn);
	    Input(in);
	    Enter(in,&signIn);
	    switch(in)
	    {
	    	case 1://���� 
	    		SignIn();
	    		break;
	    	case 2://�ػ� 
	    		systemmode=SHUTDOWN; 
	    		break;
		}
		
		if(SHUTDOWN==systemmode)
		{
			Shutdown();
			return 0;
		}
		if(REBOOT==systemmode)
		{
			Reboot();
			systemmode=START;
			GUI(language,&start,0);
			Booting();
			continue;
		}
	}
	return 0;
}

void SignIn()
{
	if(password!=no_paeeword)
	{
		GUI(language,&input_password,0);
		std::cin >> inpassword;
		if(inpassword==password)
		{
		test();
		}
		else
		{
			Print(language,&err_password,0);
			return;
		}
	}
	else
	{
		test();
	}
}

int test()
{
    using namespace std;
    int in;
    while(START==systemmode)
    {
    	std::cout << std::endl << std::endl << std::endl;
    	//Print(language,&main_menu,0);
	    GUI(language,&sys);
	    int in;
	    Input(in);
	    Enter(in,&sys);
	    switch(in)
	    {
	    case 1:
	        SystemMenu();
	        break;
	    case 2:
	        
	        break;
	    case 3:
	    	
	    	break;
	    case 4:
	    	Program();
	    	break;
	    case 5:
	    	Set();
	    	break;
	    default:
	    	
	    	break;
	    }
	}
    return 0;
}

bool Booting()
{
	
    /*std::fstream fio("puslear.dat",std::ios_base::in|std::ios_base::binary);
    if(!fio.is_open())
    {
        std::ofstream fout("puslear.dat",std::ios_base::binary|std::ios_base::out);

        return false;
    }
   // fio.read((std::string)&data,sizeof data);
    fio.close();*/
    systemmode=START;
    Stop(1);
    //std::srand(int(time(NULL)));
    //std::cout << "Eytoue Company" << std::endl << "PuslearOS" <<std::endl;
    for(int i=0;i<5;i++)
        Bootmenu();
    return true;
}

void Bootmenu()
{
    /*int i,j;
    //srand(int(time(NULL)));
    std::cout<<" PuslearOS   "<<std::endl;
    std::cout<<"[          ]\b\b\b\b\b\b\b\b\b\b\b"<<std::flush;
    for(i=0; i<10; i++)
    {
        Stop(0.1);
        std::cout<<"#"<<std::flush;
    }
    std::cout << std::endl;*/
    std::string boot01="]         ";
    std::string boot02="[]        ";
    std::string boot03=" []       ";
    std::string boot04="  []      ";
    std::string boot05="   []     ";
    std::string boot06="    []    ";
    std::string boot07="     []   ";
    std::string boot08="      []  ";
    std::string boot09="       [] ";
    std::string boot10="        []";
    std::string boot11="         [";
    std::string boot12="          ";
    std::string*pm[12]={
    &boot01,&boot02,&boot03,&boot04,
    &boot05,&boot06,&boot07,&boot08,
    &boot09,&boot10,&boot11,&boot12
    };
    for(int i=0;i<12;i++)
    {
        std::cout << *pm[i] << std::flush;
        Stop(0.09);
        std::cout <<"\b\b\b\b\b\b\b\b\b\b"<<std::flush;
        Stop(0.01);
    }
}

void Errbooting()
{
    std::cout << m_str << std::endl;
    std::cout << "����" << std::endl;
    std::cout << "Error" << std::endl<<std::endl;
    std::cout <<"�����ԭ��"<<std::endl
         <<"�޷���\"puslear.dat\"�ļ� "<<std::endl<<std::endl;
    std::cout <<"The reason for the error:"<<std::endl
         <<" Cannot open the \"puslear.dat\" file "<<std::endl;
    std::cout << m_str << std::endl;
}

void ERROR(int mode)//2021.6.24
{
	std::cout << "====================" << std::endl;
	std::cout << std::endl;
	std::cout << "                    " << std::endl;
	std::cout << "Error :             " <<std::endl;
	std::cout << "There are some wrong with this system" << std::endl << std::endl;
	std::cout << "We need to reboot this system" << std::endl;
	std::cout << "====================" << std::endl;
	Stop(3);
	systemmode=mode;
}

void Shutdown()
{
    /*std::fstream fio("puslear.dat",std::ios_base::out|std::ios_base::binary);
    if(!fio.is_open())
    {
        std::ofstream fout("puslear.dat",std::ios_base::binary|std::ios_base::out);

        return;
    }
    fio.write((std::string)&data,sizeof data);
    fio.close();*/
    GUI(language,&shutdown,0);
    for(int i=0;i<5;i++)
    {
    	Bootmenu();
	}
    return;
}

void Reboot()
{
	GUI(language,&reboot,0);
	for(int i=0;i<3;i++)
	{
		Bootmenu();
	}
	return;
}

void Stop(float a)
{
    clock_t delay = a * CLOCKS_PER_SEC;
    clock_t start=clock();
    while(clock() - start < delay)
    {
        ;
    }
}

void Print(int lga,const Menu* m,int i)//2021.6.23
{
	if(lga==CHINESE)
    {
        std::cout << m->Ch[i];
    }
    else if(lga==F_CHINESE)
    {
        std::cout << m->Fc[i];
    }
    else if(lga==ENGLISH)
    {
        std::cout << m->En[i];
    }
    else if(lga==JAPANESE)
    {
        std::cout << m->Jp[i];
    }
}

void GUI(int lga,const Menu* m,int show)
{
    std::cout << m_str <<std::endl;
    int i;
    for(i=0; i<m->menus; i++)
    {
    	if(show==1)
    	{
        std::cout << m->num[i]<<')';
    	}
        if(lga==CHINESE)
        {
            std::cout << m->Ch[i] << std::endl;
        }
        else if(lga==F_CHINESE)
        {
            std::cout << m->Fc[i] << std::endl;
        }
        else if(lga==ENGLISH)
        {
            std::cout << m->En[i] << std::endl;
        }
        else if(lga==JAPANESE)
        {
            std::cout << m->Jp[i] << std::endl;
        }
        std::cout << m_str << std::endl;
    }
}

//template<typename T>
void Input(int & a)
{
    while(!(std::cin >> a))
    {
        std::cin.clear();
        while(std::cin.get() !='\n')
        {
            continue;
        }
    }
}
int Enter(int & input,const Menu* m)
{
    int i;
    for(i=0; i<(m->menus); i++)
    {
        if(input==m->num[i])
        {
            return m->num[i];
        }
    }
    input=0;
    return 0;
}
    
void SystemMenu()
{
	int in;
	std::cout << std::endl << std::endl << std::endl;
	Print(language,&main_menu,0);
	std::cout << std::endl;
	GUI(language,&sys_m);
	Input(in);
	Enter(in,&sys_m);
	switch(in)
	{
		case 1:
			break;
		case 2:
			systemmode=SHUTDOWN;//ϵͳģʽ=�ػ� 
			break;
		case 3:
			systemmode=SIGNOUT;//ϵͳģʽ=ע�� 
			break;
		case 4:
			systemmode=REBOOT;//ϵͳģʽ=���� 
			break;
	}

}

void Program()//���� 
{
	int in;
	while(1)
	{
		std::cout << std::endl << std::endl << std::endl;
		Print(language,&sys,3);
		std::cout << std::endl;
		GUI(language,&porgram_menu);
		Input(in);
		Enter(in,&porgram_menu);
		switch(in)
		{
			case 1:
				return;
				break;
			case 2:
				Attachment();//����
				break;
			case 3:
				 break;
		}
	}
}

void Attachment()
{
	int in;
	while(1)
	{
		std::cout << std::endl << std::endl << std::endl;
		Print(language,&porgram_menu,1);
		std::cout << std::endl;
		GUI(language,&attachment_menu);
		Input(in);
		Enter(in,&attachment_menu);
		switch(in)
		{
			case 1:
				return;
				break;
			case 2:
				
				break;
			case 3:
				Games();
				break;
		}
	}
}

void Games()
{
	int in;
	while(1)
	{
		std::cout << std::endl << std::endl << std::endl;
		Print(language,&attachment_menu,2);
		std::cout << std::endl;
		GUI(language,&game_menu);
		Input(in);
		Enter(in,&game_menu);
		switch(in)
		{
			case 1:
				return;
				break;
			case 2:
				GAMES::guess();
				break;
		}
	}
}


void Set()//����
{
	int in;
	while(1)
	{
		std::cout << std::endl << std::endl << std::endl;
		Print(language,&sys,4);
		std::cout << std::endl;
		GUI(language,&set_menu);
		Input(in);
		Enter(in,&set_menu);
		switch(in)
		{
			case 1:
				return;
				break;
			case 2:
				Language_Set();//�������� 
				break;
			case 3:
				//ʱ������ 
				break;
			case 4:
				//ϵͳ���� 
				break;
			case 5:
				Sys_information();	//ϵͳ��Ϣ 
				break;
			default:
				ERROR(REBOOT);//�쳣���� 
				break; 
		}
	}
}

void Language_Set()
{
	int in;
	GUI(language,&languageSet);
	Input(in);
	Enter(in,&languageSet);
	switch(in)
	{
		case CHINESE:
		case F_CHINESE:
		case ENGLISH:
		case JAPANESE:
			language=in;
			break;
		default:
		
			break; 
	}
	return;
}

void Sys_information()//2021.6.24
{
	int in;
	std::cout << std::endl << std::endl << std::endl;
	Print(language,&set_menu,4);
	std::cout << std::endl;
	std::cout << m_str << std::endl;
	Print(language,&sys_information,0);//ϵͳ�汾 
	std::cout << SystemVersion << std::endl << m_str << std::endl;
	Print(language,&sys_information,1);//��Ȩ��Ϣ
	std::cout << "Eytoue Tems" << std::endl << m_str << std::endl;
	Print(language,&sys_information,2);
	std::cout << serial_number  << std::endl << m_str << std::endl;
	Print(language,&exitMenu,0);
	while(1)
	{
		Input(in);
		if(in==0)
		{
			break;
		}
	}
}

namespace GAMES//2021.6.23
{
	void guess()
	{
		std::cout << "********************" <<std::endl;
		int ply,com;
		int min=0;
		int max=100;
		std::srand(std::time(0));
		int pass=((std::rand()%99)+1);
		while(1)
		{
			while(1)
			{
				std::cout << std::endl;
				std::cout << min << " < " << "#" << " < " << max <<std::endl;
				std::cout <<">:";
				Input(ply);
				if(min < ply && ply < pass)
				{
					min=ply;
					break;
				}
				else if(pass < ply && ply < max)
				{
					max=ply;
					break;
				}
				else if(ply==pass)
				{
					std::cout << std::endl;
					std::cout<< min << " < " << pass << " < " << max <<std::endl;
					std::cout << "********************" <<std::endl;
					return;
				}
				else
				{
					continue;
				}
			}
			while(1)
			{
//				std::cout << min << " < " << "#" << " < " << max <<std::endl;
//				std::cout <<"PuslareOS>:";
				com=((std::rand()%99)+1);
				if(min < com && com < pass)
				{
					//min=com;������ٸ�ֵ ,��ֹ����BUG 
				}
				else if(pass < com && com < max)
				{
					//max=com;
				}
				else if(com==pass)
				{
					
				}
				else
				{
					continue;
				}
				std::cout << std::endl;
				std::cout << min << " < " << "#" << " < " << max <<std::endl;
				std::cout <<"PuslareOS>:";
				std::cout << com <<std::endl;
				if(min < com && com < pass)
				{
					min=com;
				}
				else if(pass < com && com < max)
				{
					max=com;
				}
				else if(com==pass)
				{
					std::cout << std::endl;
					std::cout<< min << " < " << pass << " < " << max <<std::endl;
					std::cout << "********************" <<std::endl;
					return;
				}
				break;
			}
		}
		std::cout << "********************" <<std::endl;
	}
}

#endif
